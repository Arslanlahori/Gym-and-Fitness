window.addEventListener('load', function () {
    var splash = document.getElementById('splash-container');
    splash.style.display = 'none';
});

// for one minute
// window.addEventListener('load', function () {
//     setTimeout(function () {
//         var splashScreen = document.getElementById('splash-screen');
//         splashScreen.parentNode.removeChild(splashScreen);
//     }, 600);
// });


